#!/bin/bash
# ==============================================================================
# Script : collect.sh
# Description :
#   Ce script interroge une API afin de récupérer les ventes des modèles de cartes graphiques suivants :
#     - rtx3060
#     - rtx3070
#     - rtx3080
#     - rtx3090
#     - rx6700
#
#   Les données collectées sont ajoutées à une copie du fichier :
#     data/raw/sales_data.csv
#
#   Le fichier de sortie est sauvegardé au format :
#     data/raw/sales_YYYYMMDD_HHMM.csv
#   avec les colonnes suivantes :
#     timestamp, model, sales
#
#   L’activité de collecte (requêtes, modèles interrogés, résultats, erreurs)
#   est enregistrée dans un fichier de log :
#     logs/collect.logs
#
#   Le log est lisible et doit inclure :
#     - La date et l’heure de chaque requête
#     - Les modèles interrogés
#     - Les ventes récupérées
#     - Les éventuelles erreurs
# ==============================================================================


# Configuration

API_URL="http://0.0.0.0:5000"

DOSSIER_RAW="data/raw"

FICHIER_SOURCE="$DOSSIER_RAW/sales_data.csv"

LOG_FILE="logs/collect.logs"


# Création des dossiers si nécessaire

mkdir -p "$DOSSIER_RAW"

mkdir -p "logs"


# Création du fichier de sortie au format demandé

DATE_FICHIER=$(date "+%Y%m%d_%H%M")

FICHIER_SORTIE="$DOSSIER_RAW/sales_${DATE_FICHIER}.csv"


# Copie des données existantes

cp "$FICHIER_SOURCE" "$FICHIER_SORTIE"

# Ajoute un saut de ligne avant les nouvelles données
echo "" >> "$FICHIER_SORTIE"

# Fonction : récupère les ventes d'un modèle via l'API

collecter_ventes () {

    modele=$1

    ventes=$(curl -s "$API_URL/$modele")

    timestamp=$(date -u "+%Y-%m-%dT%H:%M:%SZ")


    # Vérifie que l'API renvoie bien un entier positif ou nul

    if [[ "$ventes" =~ ^[0-9]+$ ]]; then

        echo "$timestamp,$modele,$ventes" >> "$FICHIER_SORTIE"

        echo "$timestamp - $modele : $ventes" >> "$LOG_FILE"

    else

        echo "$timestamp - ERREUR API pour $modele" >> "$LOG_FILE"

    fi

}


# Boucle sur les cartes graphiques

for modele in rtx3060 rtx3070 rtx3080 rtx3090 rx6700

do

    collecter_ventes "$modele"

done


echo "Collecte terminée : $FICHIER_SORTIE"
