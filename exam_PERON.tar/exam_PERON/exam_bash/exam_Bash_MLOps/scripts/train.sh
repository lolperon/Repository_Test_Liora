#!/bin/bash
# -----------------------------------------------------------------------------
# Ce script train.sh exécute le programme Python src/train.py
# Ce programme entraîne un modèle de prédiction et enregistre le modèle final
# dans le répertoire model/. Le script enregistre également tous les détails
# de l'exécution dans le fichier logs/train.logs.
# -----------------------------------------------------------------------------

# Se placer à la racine du projet
cd "$(dirname "$0")/.."
LOG_FILE="logs/train.logs"

echo "==================================================" >> "$LOG_FILE"
echo "$(date) - Début de l'entraînement" >> "$LOG_FILE"
.venv/bin/python src/train.py >> "$LOG_FILE" 2>&1

if [ $? -eq 0 ]; then
    echo "$(date) - Entraînement terminé avec succès" >> "$LOG_FILE"
else
    echo "$(date) - ERREUR pendant l'entraînement" >> "$LOG_FILE"
    exit 1
fi
