# =============================================================================
# Ce script preprocessed.sh exécute le programme src/preprocessed.py
# et enregistre les détails de son exécution dans le fichier de log
# logs/preprocessed.logs.
# =============================================================================

#!/bin/bash


# Se placer à la racine du projet

cd "$(dirname "$0")/.."

LOG_FILE="logs/preprocessed.logs"


echo "$(date) - Début du prétraitement" >> "$LOG_FILE"


# Exécution du programme Python avec l'environnement virtuel

.venv/bin/python src/preprocessed.py >> "$LOG_FILE" 2>&1


if [ $? -eq 0 ]; then

    echo "$(date) - Prétraitement terminé avec succès" >> "$LOG_FILE"

else

    echo "$(date) - ERREUR pendant le prétraitement" >> "$LOG_FILE"

    exit 1

fi

