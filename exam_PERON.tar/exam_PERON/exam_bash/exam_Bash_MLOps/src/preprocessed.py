"""
-------------------------------------------------------------------------------
Ce script preprocessed.py récupère les données du dernier fichier CSV créé 
dans le dossier 'data/raw/'.

1. Il applique un prétraitement aux données
   
2. Les résultats du prétraitement sont enregistrés dans un nouveau fichier CSV 
   dans le dossier 'data/processed/', avec un nom au format 
   'sales_processed_YYYYMMDD_HHMM.csv'.
   
3. Toutes les étapes du prétraitement sont enregistrées dans le fichier 
   'logs/preprocessed.logs' afin de garantir un suivi détaillé du processus.

Les erreurs ou anomalies éventuelles sont également loguées pour assurer la traçabilité.
-------------------------------------------------------------------------------
"""
from pathlib import Path

from datetime import datetime

import pandas as pd



RAW_DIR = Path("data/raw")

PROCESSED_DIR = Path("data/processed")


PROCESSED_DIR.mkdir(parents=True, exist_ok=True)



# Recherche du dernier fichier de données brutes

raw_files = list(RAW_DIR.glob("sales_*.csv"))


if not raw_files:

    raise FileNotFoundError("Aucun fichier sales_*.csv trouvé dans data/raw")


latest_file = max(raw_files, key=lambda f: f.stat().st_mtime)


print(f"Fichier utilisé : {latest_file}")



# Chargement des données

df = pd.read_csv(latest_file)


print(f"Nombre de lignes avant traitement : {len(df)}")



# Suppression des valeurs manquantes

df = df.dropna()



# Conversion des ventes en nombres

df["sales"] = pd.to_numeric(df["sales"], errors="coerce")


# Suppression des valeurs incorrectes

df = df.dropna(subset=["sales"])

df = df[df["sales"] >= 0]



# Suppression du timestamp

if "timestamp" in df.columns:

    df = df.drop(columns=["timestamp"])



# Transformation des modèles en valeurs numériques

model_mapping = {

    "rtx3060": 0,

    "rtx3070": 1,

    "rtx3080": 2,

    "rtx3090": 3,

    "rx6700": 4,

}


df["model"] = df["model"].map(model_mapping)



# Suppression d'un éventuel modèle inconnu

df = df.dropna(subset=["model"])



# Conversion de toutes les colonnes en entiers

df = df.astype(int)



# Création du fichier de sortie

timestamp = datetime.now().strftime("%Y%m%d_%H%M")

output_file = PROCESSED_DIR / f"sales_processed_{timestamp}.csv"


df.to_csv(output_file, index=False)


print(f"Nombre de lignes après traitement : {len(df)}")

print(f"Fichier créé : {output_file}")

print("Prétraitement terminé avec succès.")
