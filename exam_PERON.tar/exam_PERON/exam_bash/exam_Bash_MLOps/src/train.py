"""
Script d'entraînement du modèle XGBoost.

Étapes :
1. Charger le dernier fichier CSV présent dans data/processed/
2. Séparer les données en train / test
3. Entraîner un modèle XGBoost
4. Évaluer le modèle avec RMSE, MAE et R²
5. Sauvegarder le modèle dans model/
"""

from pathlib import Path

from datetime import datetime

import pickle


import pandas as pd

from xgboost import XGBRegressor

from sklearn.model_selection import train_test_split

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score



# Répertoires

DATA_DIR = Path("data/processed")

MODEL_DIR = Path("model")


MODEL_DIR.mkdir(parents=True, exist_ok=True)



# 1. Récupérer le fichier CSV le plus récent

csv_files = list(DATA_DIR.glob("*.csv"))


if not csv_files:

    raise FileNotFoundError("Aucun fichier CSV trouvé dans data/processed/")


latest_csv = max(csv_files, key=lambda f: f.stat().st_mtime)


print(f"Fichier utilisé : {latest_csv}")



# 2. Charger les données

df = pd.read_csv(latest_csv)


X = df[["model"]]

y = df["sales"]



# 3. Séparer les données train / test

X_train, X_test, y_train, y_test = train_test_split(

    X,

    y,

    test_size=0.2,

    random_state=42

)



# 4. Entraîner le modèle

model = XGBRegressor(random_state=42)

model.fit(X_train, y_train)



# 5. Faire les prédictions

predictions = model.predict(X_test)



# 6. Calculer les métriques

rmse = mean_squared_error(y_test, predictions) ** 0.5

mae = mean_absolute_error(y_test, predictions)

r2 = r2_score(y_test, predictions)


print(f"RMSE : {rmse:.4f}")

print(f"MAE  : {mae:.4f}")

print(f"R2   : {r2:.4f}")



# 7. Sauvegarder le modèle

standard_model = MODEL_DIR / "model.pkl"


if standard_model.exists():

    timestamp = datetime.now().strftime("%Y%m%d_%H%M")

    model_path = MODEL_DIR / f"model_{timestamp}.pkl"

else:

    model_path = standard_model


with open(model_path, "wb") as f:

    pickle.dump(model, f)


print(f"Modèle sauvegardé : {model_path}")
